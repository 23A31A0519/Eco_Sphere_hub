import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import ProtectedRoute from './components/ProtectedRoute';
import Initiatives from './pages/Initiatives';
import InitiativeDetails from './pages/InitiativeDetails';
import SubmitInitiative from './pages/SubmitInitiative';
import Centers from './pages/Centers';
import CenterDetails from './pages/CenterDetails';
import AddCenter from './pages/AddCenter';
import MapPage from './pages/MapPage';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/map" element={<MapPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/initiatives" element={<Initiatives />} />
        <Route path="/initiatives/:id" element={<InitiativeDetails />} />
        <Route path="/centers" element={<Centers />} />
        <Route path="/centers/:id" element={<CenterDetails />} />
        <Route 
          path="/add-center" 
          element={
            <ProtectedRoute>
              <AddCenter />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin" 
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/submit" 
          element={
            <ProtectedRoute>
              <SubmitInitiative />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
