import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import centerService from '../services/centerService';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix for default marker icon in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const LocationMarker = ({ setPosition }) => {
  const [position, setLocalPosition] = useState(null);
  useMapEvents({
    click(e) {
      setLocalPosition(e.latlng);
      setPosition(e.latlng);
    },
  });
  return position === null ? null : <Marker position={position} />;
};

const AddCenter = () => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Recycling',
    address: '',
    city: '',
    latitude: '',
    longitude: '',
    contactInfo: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const { name, description, category, address, city, latitude, longitude, contactInfo } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const setMapPosition = (latlng) => {
    setFormData({ ...formData, latitude: latlng.lat, longitude: latlng.lng });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!latitude || !longitude) {
      setError('Please select a location on the map');
      return;
    }
    try {
      await centerService.createCenter(formData);
      setSuccess('Sustainability Center saved and approved successfully.');
      setTimeout(() => {
        navigate('/centers');
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Please make sure you are an Admin.');
    }
  };

  return (
    <div className="container" style={{ margin: '40px auto', maxWidth: '800px' }}>
      <div className="form-container" style={{ width: '100%', backgroundColor: 'white' }}>
        <h2 style={{ color: 'var(--primary-green)' }}>Add Sustainability Center</h2>
        <p style={{ textAlign: 'center', marginBottom: '1.5rem', color: '#666' }}>Only admins can access this page.</p>
        
        {error && <p className="error" style={{ color: 'red' }}>{error}</p>}
        {success && <p className="success" style={{ color: 'green' }}>{success}</p>}
        
        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label>Name</label>
            <input type="text" name="name" value={name} onChange={onChange} required />
          </div>
          
          <div className="form-group">
            <label>Description</label>
            <textarea name="description" value={description} onChange={onChange} rows="4" required style={{ width: '100%', padding: '0.8rem', borderRadius: '4px', border: '1px solid #ccc' }} />
          </div>
          
          <div className="form-group" style={{ flex: 1 }}>
            <label>Category</label>
            <select name="category" value={category} onChange={onChange} required style={{ width: '100%', padding: '0.8rem', borderRadius: '4px', border: '1px solid #ccc' }}>
              <option value="Recycling">Recycling</option>
              <option value="Waste">Waste</option>
              <option value="Energy">Energy</option>
              <option value="Water">Water</option>
              <option value="NGO">NGO</option>
            </select>
          </div>
          <div className="form-group" style={{ flex: 1 }}>
            <label>City</label>
            <input type="text" name="city" value={city} onChange={onChange} required />
          </div>
          

          <div className="form-group">
            <label>Address</label>
            <input type="text" name="address" value={address} onChange={onChange} required />
          </div>

          <div className="form-group">
            <label>Location (Click on map to select)</label>
            <div style={{ height: '300px', width: '100%', marginBottom: '10px', borderRadius: '8px', overflow: 'hidden', border: '1px solid #ccc' }}>
              <MapContainer center={[51.505, -0.09]} zoom={13} style={{ height: '100%', width: '100%' }}>
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <LocationMarker setPosition={setMapPosition} />
              </MapContainer>
            </div>
            {latitude && longitude && <p style={{ fontSize: '0.9rem', color: '#666' }}>Selected: Lat {Number(latitude).toFixed(4)}, Lng {Number(longitude).toFixed(4)}</p>}
          </div>

          <div className="form-group">
            <label>Contact Info (Optional)</label>
            <input type="text" name="contactInfo" value={contactInfo} onChange={onChange} placeholder="Email, phone, or website" />
          </div>

          <button type="submit" className="btn-primary btn-block">Save Center</button>
        </form>
      </div>
    </div>
  );
};

export default AddCenter;
