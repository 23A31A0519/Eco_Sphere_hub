import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from '../services/authService';

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const { name, email, password } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      await authService.register(formData);
      navigate('/');
      window.location.reload(); // Quick way to update navbar state
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong');
    }
  };

  return (
    <div className="container">
      <div className="form-container">
        <h2>Join EcoSphere</h2>
        {error && <p className="error" style={{ color: 'red' }}>{error}</p>}
        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label>Name</label>
            <input 
              type="text" 
              name="name"
              value={name}
              onChange={onChange}
              placeholder="Enter your full name" 
              required 
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input 
              type="email" 
              name="email"
              value={email}
              onChange={onChange}
              placeholder="Enter your email" 
              required 
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input 
              type="password" 
              name="password"
              value={password}
              onChange={onChange}
              placeholder="Create a password" 
              required 
            />
          </div>
          <button type="submit" className="btn-primary btn-block">Register</button>
        </form>
      </div>
    </div>
  );
};

export default Register;
