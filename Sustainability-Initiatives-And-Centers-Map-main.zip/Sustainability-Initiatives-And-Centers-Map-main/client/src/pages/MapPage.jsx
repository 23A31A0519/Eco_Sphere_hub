import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Popup, useMap, Tooltip } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import initiativeService from '../services/initiativeService';
import centerService from '../services/centerService';

// Fix Default Icon Issue
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const createCustomIcon = (color) => {
  const markerHtmlStyles = `
    background-color: ${color};
    width: 2rem;
    height: 2rem;
    display: block;
    left: -1rem;
    top: -1rem;
    position: relative;
    border-radius: 2rem 2rem 0;
    transform: rotate(45deg);
    border: 2px solid #FFFFFF;
    box-shadow: 0 4px 6px rgba(0,0,0,0.3);
  `;

  return L.divIcon({
    className: 'custom-pin',
    iconAnchor: [0, 24],
    labelAnchor: [-6, 0],
    popupAnchor: [0, -36],
    html: `<span style="${markerHtmlStyles}" />`
  });
};

const greenIcon = createCustomIcon('var(--primary-green, #2E7D32)');
const brownIcon = createCustomIcon('var(--text-brown, #795548)');

// Component to dynamically change map view
const MapWalker = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom, { animate: true });
    }
  }, [center, zoom, map]);
  return null;
};

const MapPage = () => {
  const [initiatives, setInitiatives] = useState([]);
  const [centers, setCenters] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters state
  const [filters, setFilters] = useState({ category: '', city: '', search: '' });
  
  // Toggle states
  const [showType, setShowType] = useState('both'); // 'both', 'initiatives', 'centers'
  
  // Map View State
  const [mapCenter, setMapCenter] = useState([20.5937, 78.9629]);
  const [mapZoom, setMapZoom] = useState(5);

  useEffect(() => {
    fetchMapData();
  }, [filters]);

  const fetchMapData = async () => {
    try {
      setLoading(true);
      const [initData, centerData] = await Promise.all([
        initiativeService.getInitiatives(filters),
        centerService.getCenters(filters)
      ]);
      setInitiatives(initData.data);
      setCenters(centerData.data);
    } catch (err) {
      console.error('Error fetching data for map', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const locateUser = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setMapCenter([position.coords.latitude, position.coords.longitude]);
          setMapZoom(12);
        },
        (error) => {
          console.error("Error getting location: ", error);
          alert("Unable to retrieve your location.");
        }
      );
    } else {
      alert("Geolocation is not supported by your browser");
    }
  };

  const initiativeMarkers = useMemo(() => {
    if (showType !== 'both' && showType !== 'initiatives') return null;
    return initiatives.map(init => (
      <Marker key={`init-${init._id}`} position={[init.latitude, init.longitude]} icon={greenIcon}>
        <Tooltip direction="top" offset={[0, -20]} opacity={1}>
          Initiative: {init.title}
        </Tooltip>
        <Popup className="custom-popup">
          <div style={{ textAlign: 'center' }}>
            <h3 style={{ color: 'var(--primary-green)', margin: '0 0 0.5rem 0', fontSize: '1.2rem' }}>{init.title}</h3>
            <div style={{ marginBottom: '0.8rem' }}>
              <span style={{ display: 'inline-block', backgroundColor: '#e8f5e9', color: 'var(--primary-green)', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.8rem', marginRight: '0.5rem' }}>
                {init.category}
              </span>
              <span style={{ display: 'inline-block', backgroundColor: '#f1f1f1', color: '#666', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.8rem', textTransform: 'capitalize' }}>
                {init.status}
              </span>
            </div>
            <Link to={`/initiatives/${init._id}`} className="btn-primary" style={{ display: 'inline-block', padding: '0.4rem 1rem', fontSize: '0.9rem', width: '100%', boxSizing: 'border-box' }}>
              View Details
            </Link>
          </div>
        </Popup>
      </Marker>
    ));
  }, [initiatives, showType]);

  const centerMarkers = useMemo(() => {
    if (showType !== 'both' && showType !== 'centers') return null;
    return centers.map(center => (
      <Marker key={`center-${center._id}`} position={[center.latitude, center.longitude]} icon={brownIcon}>
        <Tooltip direction="top" offset={[0, -20]} opacity={1}>
          Center: {center.name}
        </Tooltip>
        <Popup className="custom-popup">
          <div style={{ textAlign: 'center' }}>
            <h3 style={{ color: 'var(--text-brown)', margin: '0 0 0.5rem 0', fontSize: '1.2rem' }}>{center.name}</h3>
            <div style={{ marginBottom: '0.8rem' }}>
              <span style={{ display: 'inline-block', backgroundColor: '#efebe9', color: 'var(--text-brown)', padding: '0.2rem 0.6rem', borderRadius: '12px', fontSize: '0.8rem', marginRight: '0.5rem' }}>
                {center.category}
              </span>
            </div>
            <p style={{ margin: '0 0 1rem 0', fontSize: '0.9rem', color: '#555' }}>📍 {center.address}</p>
            <Link to={`/centers/${center._id}`} className="btn-primary" style={{ display: 'inline-block', padding: '0.4rem 1rem', fontSize: '0.9rem', width: '100%', boxSizing: 'border-box', backgroundColor: 'var(--text-brown)' }}>
              View Details
            </Link>
          </div>
        </Popup>
      </Marker>
    ));
  }, [centers, showType]);

  return (
    <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1200px' }}>
      <h1 style={{ textAlign: 'center', color: 'var(--primary-green)', marginBottom: '1.5rem' }}>Interactive Eco Map</h1>
      
      {/* Controls & Filters Section */}
      <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', marginBottom: '1.5rem' }}>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center', alignItems: 'center', marginBottom: '1.5rem' }}>
          {/* Toggles */}
          <div style={{ display: 'flex', backgroundColor: '#f0f0f0', borderRadius: '8px', overflow: 'hidden' }}>
            <button 
              onClick={() => setShowType('both')} 
              style={{ padding: '0.6rem 1.2rem', backgroundColor: showType === 'both' ? 'var(--primary-green)' : 'transparent', color: showType === 'both' ? 'white' : '#555', borderRadius: 0 }}
            >
              Show Both
            </button>
            <button 
              onClick={() => setShowType('initiatives')} 
              style={{ padding: '0.6rem 1.2rem', backgroundColor: showType === 'initiatives' ? 'var(--primary-green)' : 'transparent', color: showType === 'initiatives' ? 'white' : '#555', borderRadius: 0 }}
            >
              Initiatives Only
            </button>
            <button 
              onClick={() => setShowType('centers')} 
              style={{ padding: '0.6rem 1.2rem', backgroundColor: showType === 'centers' ? 'var(--primary-green)' : 'transparent', color: showType === 'centers' ? 'white' : '#555', borderRadius: 0 }}
            >
              Centers Only
            </button>
          </div>

          <button onClick={locateUser} className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            🧭 Show My Location
          </button>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center' }}>
          <input 
            type="text" 
            name="search" 
            placeholder="Search by title/name..." 
            value={filters.search} 
            onChange={handleFilterChange}
            style={{ padding: '0.6rem 1rem', borderRadius: '8px', border: '1px solid #ddd', minWidth: '220px' }}
          />
          <input 
            type="text" 
            name="city" 
            placeholder="Filter by city..." 
            value={filters.city} 
            onChange={handleFilterChange}
            style={{ padding: '0.6rem 1rem', borderRadius: '8px', border: '1px solid #ddd', minWidth: '180px' }}
          />
          <select 
            name="category" 
            value={filters.category} 
            onChange={handleFilterChange}
            style={{ padding: '0.6rem', borderRadius: '8px', border: '1px solid #ddd', minWidth: '180px' }}
          >
            <option value="">All Categories</option>
            <option value="Waste">Waste</option>
            <option value="Recycling">Recycling (Centers)</option>
            <option value="Energy">Energy</option>
            <option value="Water">Water (Centers)</option>
            <option value="Conservation">Conservation (Initiatives)</option>
            <option value="Community">Community (Initiatives)</option>
            <option value="NGO">NGO (Centers)</option>
          </select>
        </div>
      </div>

      {loading && <p style={{ textAlign: 'center' }}>Loading map data...</p>}

      {/* Map Section */}
      <div style={{ position: 'relative', height: '600px', borderRadius: '16px', overflow: 'hidden', boxShadow: '0 8px 24px rgba(0,0,0,0.1)', border: '2px solid white' }}>
        
        {/* Legend */}
        <div style={{ position: 'absolute', bottom: '20px', left: '20px', zIndex: 1000, backgroundColor: 'white', padding: '1rem', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
          <h4 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>Legend</h4>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <span style={{ display: 'inline-block', width: '16px', height: '16px', backgroundColor: 'var(--primary-green)', borderRadius: '50%' }}></span>
            <span style={{ fontSize: '0.9rem', color: '#555' }}>Initiatives</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ display: 'inline-block', width: '16px', height: '16px', backgroundColor: 'var(--text-brown)', borderRadius: '50%' }}></span>
            <span style={{ fontSize: '0.9rem', color: '#555' }}>Sustainability Centers</span>
          </div>
        </div>

        <MapContainer center={mapCenter} zoom={mapZoom} style={{ height: '600px', width: '100%' }}>
          <MapWalker center={mapCenter} zoom={mapZoom} />
          <TileLayer 
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" 
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />

          {initiativeMarkers}
          {centerMarkers}
          
        </MapContainer>
      </div>
    </div>
  );
};

export default MapPage;
