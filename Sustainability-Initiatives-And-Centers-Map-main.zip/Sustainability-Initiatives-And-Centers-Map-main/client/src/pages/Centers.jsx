import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import centerService from '../services/centerService';

const Centers = () => {
  const [centers, setCenters] = useState([]);
  const [filters, setFilters] = useState({ search: '', category: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCenters();
  }, [filters]);

  const fetchCenters = async () => {
    try {
      setLoading(true);
      const data = await centerService.getCenters(filters);
      setCenters(data.data);
    } catch (err) {
      console.error('Error fetching centers:', err);
    } finally {
      setLoading(false);
    }
  };

  const onChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleGoogleMapsRedirect = () => {
    const queryCat = filters.category ? filters.category : 'Sustainability';
    const googleMapUrl = `https://www.google.com/maps/search/?api=1&query=${queryCat}+centers+near+me`;
    window.open(googleMapUrl, '_blank');
  };

  return (
    <div className="container" style={{ padding: '2rem 1rem' }}>
      <h1 style={{ marginBottom: '1.5rem', textAlign: 'center', color: 'var(--primary-green)' }}>Sustainability Centers</h1>
      
      {/* Filters Section */}
      <div className="filters-section" style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap', justifyContent: 'center' }}>
        <input 
          type="text" 
          name="search" 
          placeholder="Search by center name..." 
          value={filters.search} 
          onChange={onChange}
          style={{ padding: '0.6rem 1rem', borderRadius: '4px', border: '1px solid #ddd', minWidth: '250px' }}
        />
        <select 
          name="category" 
          value={filters.category} 
          onChange={onChange}
          style={{ padding: '0.6rem', borderRadius: '4px', border: '1px solid #ddd' }}
        >
          <option value="">All Categories</option>
          <option value="Recycling">Recycling</option>
          <option value="Waste">Waste</option>
          <option value="Energy">Energy</option>
          <option value="Water">Water</option>
          <option value="NGO">NGO</option>
        </select>
        <button 
          onClick={handleGoogleMapsRedirect}
          className="btn-secondary"
          style={{ padding: '0.6rem 1.2rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
        >
          📍 Find More Nearby on Google Maps
        </button>
      </div>

      {loading ? (
        <p style={{ textAlign: 'center' }}>Loading centers...</p>
      ) : (
        <div className="initiatives-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '2rem' }}>
          {centers.length > 0 ? centers.map(center => (
            <div key={center._id} className="initiative-card" style={{ 
              backgroundColor: 'white', 
              borderRadius: '12px', 
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)', 
              padding: '1.5rem',
              display: 'flex',
              flexDirection: 'column',
              transition: 'transform 0.2s',
              border: '1px solid #eee'
            }}>
              <div style={{ marginBottom: '1rem' }}>
                <span style={{ 
                  backgroundColor: 'var(--text-brown)', 
                  color: 'white', 
                  padding: '0.2rem 0.6rem', 
                  borderRadius: '12px', 
                  fontSize: '0.8rem' 
                }}>{center.category}</span>
              </div>
              
              <h3 style={{ margin: '0 0 0.5rem 0', color: 'var(--primary-green)' }}>{center.name}</h3>
              <p style={{ color: '#666', fontSize: '0.9rem', marginBottom: '1rem' }}>
                📍 {center.city}
              </p>
              
              <p style={{ fontSize: '0.95rem', color: '#555', marginBottom: '1.5rem', flex: 1 }}>
                {center.description && center.description.length > 100 ? `${center.description.substring(0, 100)}...` : center.description}
              </p>
              
              <Link 
                to={`/centers/${center._id}`} 
                className="btn-primary" 
                style={{ textAlign: 'center', display: 'block', textDecoration: 'none' }}
              >
                View Details
              </Link>
            </div>
          )) : (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center' }}>No approved centers found matching your criteria.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Centers;
