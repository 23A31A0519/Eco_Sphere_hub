import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import centerService from '../services/centerService';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix for default marker icon in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const CenterDetails = () => {
  const { id } = useParams();
  const [center, setCenter] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCenter = async () => {
      try {
        const data = await centerService.getCenterById(id);
        setCenter(data.data);
      } catch (err) {
        setError('Center not found or an error occurred.');
      } finally {
        setLoading(false);
      }
    };
    fetchCenter();
  }, [id]);

  if (loading) return <div style={{ textAlign: 'center', marginTop: '2rem' }}>Loading center details...</div>;
  if (error) return <div style={{ textAlign: 'center', marginTop: '2rem', color: 'red' }}>{error}</div>;
  if (!center) return null;

  return (
    <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1000px', margin: '0 auto' }}>
      <Link to="/centers" style={{ color: 'var(--primary-green)', textDecoration: 'none', marginBottom: '1rem', display: 'inline-block' }}>
        &larr; Back to Centers
      </Link>
      
      <div style={{ backgroundColor: 'white', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', padding: '2rem', marginTop: '1rem' }}>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
          <span style={{ backgroundColor: 'var(--text-brown)', color: 'white', padding: '0.3rem 0.8rem', borderRadius: '16px', fontSize: '0.9rem' }}>
            {center.category}
          </span>
        </div>

        <h1 style={{ color: 'var(--primary-green)', marginBottom: '0.5rem', fontSize: '2.5rem' }}>{center.name}</h1>
        <p style={{ color: '#666', fontSize: '1.1rem', marginBottom: '2rem' }}>📍 {center.address}, {center.city}</p>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem' }}>
          <div style={{ flex: '1 1 500px' }}>
            <h3 style={{ color: 'var(--primary-green)', marginBottom: '1rem' }}>About this Center</h3>
            <p style={{ lineHeight: '1.6', color: '#444', whiteSpace: 'pre-wrap', marginBottom: '2rem' }}>
              {center.description}
            </p>

            {center.contactInfo && (
              <>
                <h3 style={{ color: 'var(--primary-green)', marginBottom: '0.5rem' }}>Contact Information</h3>
                <p style={{ color: '#444' }}>{center.contactInfo}</p>
              </>
            )}
          </div>

          <div style={{ flex: '1 1 300px' }}>
            <h3 style={{ color: 'var(--primary-green)', marginBottom: '1rem' }}>Location Map</h3>
            <div style={{ height: '300px', borderRadius: '8px', overflow: 'hidden', border: '1px solid #ddd' }}>
              <MapContainer 
                center={[center.latitude, center.longitude]} 
                zoom={15} 
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <Marker position={[center.latitude, center.longitude]} />
              </MapContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CenterDetails;
