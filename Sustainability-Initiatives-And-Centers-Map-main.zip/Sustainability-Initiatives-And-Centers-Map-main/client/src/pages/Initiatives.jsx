import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import initiativeService from '../services/initiativeService';
import '../index.css';

const Initiatives = () => {
  const [initiatives, setInitiatives] = useState([]);
  const [filters, setFilters] = useState({ search: '', category: '', status: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInitiatives();
  }, [filters]);

  const fetchInitiatives = async () => {
    try {
      setLoading(true);
      const data = await initiativeService.getInitiatives(filters);
      setInitiatives(data.data);
    } catch (err) {
      console.error('Error fetching initiatives', err);
    } finally {
      setLoading(false);
    }
  };

  const onChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'upcoming': return 'var(--primary-blue, #3498db)';
      case 'ongoing': return 'var(--forest-green, #2ecc71)';
      case 'completed': return 'var(--soft-gray, #95a5a6)';
      default: return '#ccc';
    }
  };

  return (
    <div className="container" style={{ padding: '2rem 1rem' }}>
      <h1 style={{ marginBottom: '1.5rem', textAlign: 'center', color: 'var(--text-dark)' }}>Sustainability Initiatives</h1>
      
      {/* Filters Section */}
      <div className="filters-section" style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap', justifyContent: 'center' }}>
        <input 
          type="text" 
          name="search" 
          placeholder="Search by title..." 
          value={filters.search} 
          onChange={onChange}
          style={{ padding: '0.6rem 1rem', borderRadius: '4px', border: '1px solid #ddd', minWidth: '250px' }}
        />
        <select 
          name="category" 
          value={filters.category} 
          onChange={onChange}
          style={{ padding: '0.6rem', borderRadius: '4px', border: '1px solid #ddd' }}
        >
          <option value="">All Categories</option>
          <option value="Waste">Waste</option>
          <option value="Energy">Energy</option>
          <option value="Conservation">Conservation</option>
          <option value="Community">Community</option>
        </select>
        <select 
          name="status" 
          value={filters.status} 
          onChange={onChange}
          style={{ padding: '0.6rem', borderRadius: '4px', border: '1px solid #ddd' }}
        >
          <option value="">All Statuses</option>
          <option value="upcoming">Upcoming</option>
          <option value="ongoing">Ongoing</option>
          <option value="completed">Completed</option>
        </select>
      </div>

      {loading ? (
        <p style={{ textAlign: 'center' }}>Loading initiatives...</p>
      ) : (
        <div className="initiatives-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '2rem' }}>
          {initiatives.length > 0 ? initiatives.map(initiative => (
            <div key={initiative._id} className="initiative-card" style={{ 
              backgroundColor: 'var(--off-white)', 
              borderRadius: '12px', 
              boxShadow: '0 4px 6px rgba(0,0,0,0.1)', 
              padding: '1.5rem',
              display: 'flex',
              flexDirection: 'column',
              transition: 'transform 0.2s',
              border: '1px solid #eee'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                <span style={{ 
                  backgroundColor: 'var(--earth-brown)', 
                  color: 'white', 
                  padding: '0.2rem 0.6rem', 
                  borderRadius: '12px', 
                  fontSize: '0.8rem' 
                }}>{initiative.category}</span>
                
                <span style={{ 
                  backgroundColor: getStatusColor(initiative.status), 
                  color: 'white', 
                  padding: '0.2rem 0.6rem', 
                  borderRadius: '12px', 
                  fontSize: '0.8rem',
                  textTransform: 'capitalize'
                }}>{initiative.status}</span>
              </div>
              
              <h3 style={{ margin: '0 0 0.5rem 0', color: 'var(--text-dark)' }}>{initiative.title}</h3>
              <p style={{ color: 'var(--text-light)', fontSize: '0.9rem', marginBottom: '1rem' }}>
                📍 {initiative.city}
              </p>
              
              <p style={{ fontSize: '0.95rem', color: '#555', marginBottom: '1.5rem', flex: 1 }}>
                {initiative.description.length > 100 ? `${initiative.description.substring(0, 100)}...` : initiative.description}
              </p>
              
              <Link 
                to={`/initiatives/${initiative._id}`} 
                className="btn-primary" 
                style={{ textAlign: 'center', display: 'block', textDecoration: 'none' }}
              >
                View Details
              </Link>
            </div>
          )) : (
            <p style={{ gridColumn: '1 / -1', textAlign: 'center' }}>No approved initiatives found matching your criteria.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Initiatives;
