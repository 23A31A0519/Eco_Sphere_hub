import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import adminService from '../services/adminService';
import authService from '../services/authService';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({ totalInitiatives: 0, totalCenters: 0, totalUsers: 0, pendingInitiatives: 0 });
  const [pendingInitiatives, setPendingInitiatives] = useState([]);
  const [centers, setCenters] = useState([]);
  const [users, setUsers] = useState([]);
  
  // Create Admin Form State
  const [adminData, setAdminData] = useState({ name: '', email: '', password: '', region: '' });
  const [message, setMessage] = useState({ type: '', text: '' });
  
  const currentUser = authService.getCurrentUser();
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'superadmin')) {
      navigate('/');
      return;
    }
    fetchData();
  }, [currentUser, navigate]);

  const fetchData = async () => {
    try {
      const statsRes = await adminService.getDashboardStats();
      setStats(statsRes.data);
      
      const initiativesRes = await adminService.getPendingInitiatives();
      setPendingInitiatives(initiativesRes.data);
      
      const centersRes = await adminService.getAllCenters();
      setCenters(centersRes.data);

      if (currentUser.role === 'superadmin') {
        const usersRes = await adminService.getUsers();
        setUsers(usersRes.data);
      }
    } catch (err) {
      console.error('Error fetching admin data', err);
    }
  };

  const handleApprove = async (id) => {
    try {
      await adminService.approveInitiative(id);
      fetchData(); // Refresh data
    } catch (err) {
      alert("Failed to approve initiative");
    }
  };

  const handleReject = async (id) => {
    if (window.confirm("Are you sure you want to reject this initiative?")) {
      try {
        await adminService.rejectInitiative(id);
        fetchData();
      } catch (err) {
        alert("Failed to reject initiative");
      }
    }
  };

  const handleDeleteCenter = async (id) => {
    if (window.confirm("Are you sure you want to delete this center?")) {
      try {
        await adminService.deleteCenter(id);
        fetchData();
      } catch (err) {
        alert("Failed to delete center");
      }
    }
  };

  const handleAdminChange = (e) => {
    setAdminData({ ...adminData, [e.target.name]: e.target.value });
  };

  const handleCreateAdmin = async (e) => {
    e.preventDefault();
    try {
      await adminService.createAdmin(adminData);
      setMessage({ type: 'success', text: 'Admin created successfully!' });
      setAdminData({ name: '', email: '', password: '', region: '' });
      fetchData();
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.message || 'Failed to create admin' });
    }
  };

  return (
    <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1200px' }}>
      <h1 style={{ color: 'var(--primary-green)', marginBottom: '1.5rem', borderBottom: '2px solid var(--primary-green)', paddingBottom: '0.5rem' }}>
        Admin Dashboard
      </h1>

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
        <button className={activeTab === 'overview' ? 'btn-primary' : 'btn-secondary'} onClick={() => setActiveTab('overview')}>Overview</button>
        <button className={activeTab === 'initiatives' ? 'btn-primary' : 'btn-secondary'} onClick={() => setActiveTab('initiatives')}>Pending Initiatives ({stats.pendingInitiatives})</button>
        <button className={activeTab === 'centers' ? 'btn-primary' : 'btn-secondary'} onClick={() => setActiveTab('centers')}>Manage Centers</button>
        {currentUser?.role === 'superadmin' && (
          <button className={activeTab === 'users' ? 'btn-primary' : 'btn-secondary'} onClick={() => setActiveTab('users')}>Manage Users</button>
        )}
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '200px', padding: '1.5rem', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', textAlign: 'center' }}>
            <h3 style={{ margin: 0, color: '#666' }}>Total Initiatives</h3>
            <p style={{ fontSize: '3rem', margin: '0.5rem 0', color: 'var(--primary-green)', fontWeight: 'bold' }}>{stats.totalInitiatives}</p>
          </div>
          <div style={{ flex: 1, minWidth: '200px', padding: '1.5rem', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', textAlign: 'center' }}>
            <h3 style={{ margin: 0, color: '#666' }}>Pending Approval</h3>
            <p style={{ fontSize: '3rem', margin: '0.5rem 0', color: 'orange', fontWeight: 'bold' }}>{stats.pendingInitiatives}</p>
          </div>
          <div style={{ flex: 1, minWidth: '200px', padding: '1.5rem', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', textAlign: 'center' }}>
            <h3 style={{ margin: 0, color: '#666' }}>Total Centers</h3>
            <p style={{ fontSize: '3rem', margin: '0.5rem 0', color: 'var(--text-brown)', fontWeight: 'bold' }}>{stats.totalCenters}</p>
          </div>
          <div style={{ flex: 1, minWidth: '200px', padding: '1.5rem', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', textAlign: 'center' }}>
            <h3 style={{ margin: 0, color: '#666' }}>Total Users</h3>
            <p style={{ fontSize: '3rem', margin: '0.5rem 0', color: '#333', fontWeight: 'bold' }}>{stats.totalUsers}</p>
          </div>
        </div>
      )}

      {/* PENDING INITIATIVES TAB */}
      {activeTab === 'initiatives' && (
        <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
          <h2 style={{ marginTop: 0 }}>Pending Initiatives</h2>
          {pendingInitiatives.length === 0 ? <p>No pending initiatives to review.</p> : (
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #eee' }}>
                  <th style={{ padding: '1rem 0' }}>Title</th>
                  <th>Category</th>
                  <th>City</th>
                  <th>Submitted By</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {pendingInitiatives.map(init => (
                  <tr key={init._id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '1rem 0' }}>{init.title}</td>
                    <td>{init.category}</td>
                    <td>{init.city}</td>
                    <td>{init.createdBy?.name || 'Unknown'}</td>
                    <td>
                      <button onClick={() => handleApprove(init._id)} style={{ backgroundColor: 'var(--primary-green)', color: 'white', padding: '0.4rem 0.8rem', borderRadius: '4px', marginRight: '0.5rem' }}>Approve</button>
                      <button onClick={() => handleReject(init._id)} style={{ backgroundColor: '#f44336', color: 'white', padding: '0.4rem 0.8rem', borderRadius: '4px' }}>Reject</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* CENTERS TAB */}
      {activeTab === 'centers' && (
        <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
          <h2 style={{ marginTop: 0 }}>Manage Centers</h2>
          {centers.length === 0 ? <p>No centers found.</p> : (
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #eee' }}>
                  <th style={{ padding: '1rem 0' }}>Name</th>
                  <th>Category</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {centers.map(center => (
                  <tr key={center._id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '1rem 0' }}>{center.name}</td>
                    <td>{center.category}</td>
                    <td>{center.city}</td>
                    <td><span style={{ padding: '0.2rem 0.6rem', borderRadius: '12px', backgroundColor: center.approvalStatus === 'approved' ? '#e8f5e9' : '#fff3e0', color: center.approvalStatus === 'approved' ? 'var(--primary-green)' : 'orange' }}>{center.approvalStatus}</span></td>
                    <td>
                      <button onClick={() => handleDeleteCenter(center._id)} style={{ backgroundColor: '#f44336', color: 'white', padding: '0.4rem 0.8rem', borderRadius: '4px' }}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* USER MANAGEMENT TAB (Superadmin Only) */}
      {activeTab === 'users' && currentUser?.role === 'superadmin' && (
        <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
          
          <div style={{ flex: '1 1 400px', backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
            <h2 style={{ marginTop: 0 }}>Create New Admin</h2>
            {message.text && <p style={{ color: message.type === 'error' ? 'red' : 'green' }}>{message.text}</p>}
            <form onSubmit={handleCreateAdmin}>
              <div className="form-group">
                <label>Name</label>
                <input type="text" name="name" value={adminData.name} onChange={handleAdminChange} required />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input type="email" name="email" value={adminData.email} onChange={handleAdminChange} required />
              </div>
              <div className="form-group">
                <label>Password</label>
                <input type="password" name="password" value={adminData.password} onChange={handleAdminChange} required />
              </div>
              <div className="form-group">
                <label>Region</label>
                <input type="text" name="region" value={adminData.region} onChange={handleAdminChange} />
              </div>
              <button type="submit" className="btn-primary btn-block">Create Admin</button>
            </form>
          </div>

          <div style={{ flex: '2 1 500px', backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', height: 'fit-content' }}>
            <h2 style={{ marginTop: 0 }}>All Users</h2>
            <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid #eee' }}>
                    <th style={{ padding: '1rem 0' }}>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Region</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u._id} style={{ borderBottom: '1px solid #eee' }}>
                      <td style={{ padding: '1rem 0' }}>{u.name}</td>
                      <td>{u.email}</td>
                      <td>
                        <span style={{ 
                          padding: '0.2rem 0.6rem', 
                          borderRadius: '12px', 
                          backgroundColor: u.role === 'superadmin' ? '#ffebee' : u.role === 'admin' ? '#e3f2fd' : '#f5f5f5', 
                          color: u.role === 'superadmin' ? '#c62828' : u.role === 'admin' ? '#1565c0' : '#666',
                          fontSize: '0.8rem'
                        }}>
                          {u.role.toUpperCase()}
                        </span>
                      </td>
                      <td>{u.region || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
