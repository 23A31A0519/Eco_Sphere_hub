import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { testApi } from '../services/api';

const Home = () => {
  const [apiMessage, setApiMessage] = useState('');
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchApiMessage = async () => {
      try {
        const data = await testApi();
        setApiMessage(data.message);
        setError(false);
      } catch (err) {
        setApiMessage('Failed to connect to backend.');
        setError(true);
      }
    };

    fetchApiMessage();
  }, []);

  return (
    <div className="container">
      <div className="hero">
        <h1>Discover Sustainability Around You</h1>
        <p>Explore initiatives, connect with the community, and make a real impact on our planet.</p>
        <div className="hero-buttons">
          <Link to="/initiatives" className="btn-primary">Explore Initiatives</Link>
          <Link to="/submit" className="btn-secondary">Add Initiative</Link>
        </div>
        
        {apiMessage && (
          <div className={`api-message ${error ? 'error' : 'success'}`}>
            Backend Status: <strong>{apiMessage}</strong>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
