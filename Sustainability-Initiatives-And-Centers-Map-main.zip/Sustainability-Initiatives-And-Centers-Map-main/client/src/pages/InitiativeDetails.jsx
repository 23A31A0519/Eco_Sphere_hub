import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import initiativeService from '../services/initiativeService';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix for default marker icon in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const InitiativeDetails = () => {
  const { id } = useParams();
  const [initiative, setInitiative] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchInitiative = async () => {
      try {
        const data = await initiativeService.getInitiativeById(id);
        setInitiative(data.data);
      } catch (err) {
        setError('Initiative not found or an error occurred.');
      } finally {
        setLoading(false);
      }
    };
    fetchInitiative();
  }, [id]);

  if (loading) return <div style={{ textAlign: 'center', marginTop: '2rem' }}>Loading initiative details...</div>;
  if (error) return <div style={{ textAlign: 'center', marginTop: '2rem', color: 'red' }}>{error}</div>;
  if (!initiative) return null;

  const getStatusColor = (status) => {
    switch (status) {
      case 'upcoming': return '#3498db';
      case 'ongoing': return 'var(--forest-green, #2ecc71)';
      case 'completed': return '#95a5a6';
      default: return '#ccc';
    }
  };

  return (
    <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1000px', margin: '0 auto' }}>
      <Link to="/initiatives" style={{ color: 'var(--forest-green)', textDecoration: 'none', marginBottom: '1rem', display: 'inline-block' }}>
        &larr; Back to Initiatives
      </Link>
      
      <div style={{ backgroundColor: 'var(--off-white)', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', padding: '2rem', marginTop: '1rem' }}>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
          <span style={{ backgroundColor: 'var(--earth-brown)', color: 'white', padding: '0.3rem 0.8rem', borderRadius: '16px', fontSize: '0.9rem' }}>
            {initiative.category}
          </span>
          <span style={{ backgroundColor: getStatusColor(initiative.status), color: 'white', padding: '0.3rem 0.8rem', borderRadius: '16px', fontSize: '0.9rem', textTransform: 'capitalize' }}>
            {initiative.status}
          </span>
        </div>

        <h1 style={{ color: 'var(--text-dark)', marginBottom: '0.5rem', fontSize: '2.5rem' }}>{initiative.title}</h1>
        <p style={{ color: 'var(--text-light)', fontSize: '1.1rem', marginBottom: '2rem' }}>📍 {initiative.city} • <small>Added by {initiative.createdBy?.name || 'Unknown'}</small></p>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem' }}>
          <div style={{ flex: '1 1 500px' }}>
            <h3 style={{ color: 'var(--forest-green)', marginBottom: '1rem' }}>About this Initiative</h3>
            <p style={{ lineHeight: '1.6', color: '#444', whiteSpace: 'pre-wrap', marginBottom: '2rem' }}>
              {initiative.description}
            </p>

            {initiative.contactInfo && (
              <>
                <h3 style={{ color: 'var(--forest-green)', marginBottom: '0.5rem' }}>Contact Information</h3>
                <p style={{ color: '#444' }}>{initiative.contactInfo}</p>
              </>
            )}
          </div>

          <div style={{ flex: '1 1 300px' }}>
            <h3 style={{ color: 'var(--forest-green)', marginBottom: '1rem' }}>Location Map</h3>
            <div style={{ height: '300px', borderRadius: '8px', overflow: 'hidden', border: '1px solid #ddd' }}>
              <MapContainer 
                center={[initiative.latitude, initiative.longitude]} 
                zoom={14} 
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <Marker position={[initiative.latitude, initiative.longitude]} />
              </MapContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InitiativeDetails;
