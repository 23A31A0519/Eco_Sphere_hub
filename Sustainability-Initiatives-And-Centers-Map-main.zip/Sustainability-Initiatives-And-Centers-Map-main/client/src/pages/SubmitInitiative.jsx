import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import initiativeService from '../services/initiativeService';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix for default marker icon in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const LocationMarker = ({ setPosition }) => {
  const [position, setLocalPosition] = useState(null);
  useMapEvents({
    click(e) {
      setLocalPosition(e.latlng);
      setPosition(e.latlng);
    },
  });
  return position === null ? null : <Marker position={position} />;
};

const SubmitInitiative = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Waste',
    city: '',
    latitude: '',
    longitude: '',
    contactInfo: '',
    status: 'upcoming',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const { title, description, category, city, latitude, longitude, contactInfo, status } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const setMapPosition = (latlng) => {
    setFormData({ ...formData, latitude: latlng.lat, longitude: latlng.lng });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!latitude || !longitude) {
      setError('Please select a location on the map');
      return;
    }
    try {
      await initiativeService.createInitiative(formData);
      setSuccess('Submitted for approval. You will be redirected shortly.');
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong');
    }
  };

  return (
    <div className="container" style={{ margin: '40px auto', maxWidth: '800px' }}>
      <div className="form-container" style={{ width: '100%' }}>
        <h2>Submit an Initiative</h2>
        {error && <p className="error" style={{ color: 'red' }}>{error}</p>}
        {success && <p className="success" style={{ color: 'green' }}>{success}</p>}
        
        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label>Title</label>
            <input type="text" name="title" value={title} onChange={onChange} required />
          </div>
          
          <div className="form-group">
            <label>Description</label>
            <textarea name="description" value={description} onChange={onChange} rows="4" required style={{ width: '100%', padding: '0.8rem', borderRadius: '4px', border: '1px solid #ddd' }} />
          </div>

          <div style={{ display: 'flex', gap: '20px' }}>
            <div className="form-group" style={{ flex: 1 }}>
              <label>Category</label>
              <select name="category" value={category} onChange={onChange} required style={{ width: '100%', padding: '0.8rem', borderRadius: '4px', border: '1px solid #ddd' }}>
                <option value="Waste">Waste</option>
                <option value="Energy">Energy</option>
                <option value="Conservation">Conservation</option>
                <option value="Community">Community</option> 
              </select>
            </div>
            <div className="form-group" style={{ flex: 1 }}>
              <label>Status</label>
              <select name="status" value={status} onChange={onChange} required style={{ width: '100%', padding: '0.8rem', borderRadius: '4px', border: '1px solid #ddd' }}>
                <option value="upcoming">Upcoming</option>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>City</label>
            <input type="text" name="city" value={city} onChange={onChange} required />
          </div>

          <div className="form-group">
            <label>Location (Click on map to select)</label>
            <div style={{ height: '300px', width: '100%', marginBottom: '10px', borderRadius: '8px', overflow: 'hidden', border: '1px solid #ddd' }}>
              <MapContainer center={[51.505, -0.09]} zoom={13} style={{ height: '100%', width: '100%' }}>
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <LocationMarker setPosition={setMapPosition} />
              </MapContainer>
            </div>
            {latitude && longitude && <p style={{ fontSize: '0.9rem', color: '#666' }}>Selected: Lat {Number(latitude).toFixed(4)}, Lng {Number(longitude).toFixed(4)}</p>}
          </div>

          <div className="form-group">
            <label>Contact Info (Optional)</label>
            <input type="text" name="contactInfo" value={contactInfo} onChange={onChange} placeholder="Email, phone, or website" />
          </div>

          <button type="submit" className="btn-primary btn-block">Submit for Approval</button>
        </form>
      </div>
    </div>
  );
};

export default SubmitInitiative;
