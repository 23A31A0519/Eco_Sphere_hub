import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import authService from '../services/authService';

const Navbar = () => {
  const navigate = useNavigate();
  const user = authService.getCurrentUser();

  const onLogout = () => {
    authService.logout();
    navigate('/login');
    window.location.reload();
  };

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-logo">
        EcoSphere
      </Link>
      <div className="navbar-links">
        <Link to="/">Home</Link>
        <Link to="/map" style={{ fontWeight: 'bold', color: 'var(--primary-green)' }}>Eco Map</Link>
        <Link to="/initiatives">Explore Initiatives</Link>
        <Link to="/centers">Sustainability Centers</Link>
        {user ? (
          <>
            <Link to="/submit" style={{ color: 'white', backgroundColor: 'var(--primary-green)', padding: '8px 16px', borderRadius: '8px' }}>Submit Initiative</Link>
            {(user.role === 'admin' || user.role === 'superadmin') && (
              <Link to="/add-center" style={{ color: 'white', backgroundColor: 'var(--text-brown)', padding: '8px 16px', borderRadius: '8px' }}>Add Center</Link>
            )}
            <Link to="/dashboard">Dashboard</Link>
            <span style={{ color: 'var(--text-dark)', marginRight: '1rem', fontWeight: 'bold' }}>Welcome, {user.name}</span>
            <button onClick={onLogout} style={{ background: 'none', border: 'none', color: 'var(--text-dark)', cursor: 'pointer', fontSize: '1rem', fontFamily: 'inherit', fontWeight: 'bold' }}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
