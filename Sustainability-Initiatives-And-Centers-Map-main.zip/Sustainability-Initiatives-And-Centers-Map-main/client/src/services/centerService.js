import api from './api';

const getCenters = async (filters) => {
  const params = new URLSearchParams(filters).toString();
  const response = await api.get(`/centers?${params}`);
  return response.data;
};

const getCenterById = async (id) => {
  const response = await api.get(`/centers/${id}`);
  return response.data;
};

const createCenter = async (data) => {
  const response = await api.post('/centers', data);
  return response.data;
};

const updateCenter = async (id, data) => {
  const response = await api.put(`/centers/${id}`, data);
  return response.data;
};

const deleteCenter = async (id) => {
  const response = await api.delete(`/centers/${id}`);
  return response.data;
};

const centerService = {
  getCenters,
  getCenterById,
  createCenter,
  updateCenter,
  deleteCenter,
};

export default centerService;
