import api from './api';

const getDashboardStats = async () => {
  const response = await api.get('/admin/stats');
  return response.data;
};

const getPendingInitiatives = async () => {
  const response = await api.get('/admin/initiatives/pending');
  return response.data;
};

const approveInitiative = async (id) => {
  const response = await api.put(`/admin/initiatives/${id}/approve`);
  return response.data;
};

const rejectInitiative = async (id) => {
  const response = await api.put(`/admin/initiatives/${id}/reject`);
  return response.data;
};

const getAllCenters = async () => {
  const response = await api.get('/admin/centers');
  return response.data;
};

const updateCenter = async (id, data) => {
  const response = await api.put(`/admin/centers/${id}`, data);
  return response.data;
};

const deleteCenter = async (id) => {
  const response = await api.delete(`/admin/centers/${id}`);
  return response.data;
};

const getUsers = async () => {
  const response = await api.get('/admin/users');
  return response.data;
};

const createAdmin = async (data) => {
  const response = await api.post('/admin/create-admin', data);
  return response.data;
};

const adminService = {
  getDashboardStats,
  getPendingInitiatives,
  approveInitiative,
  rejectInitiative,
  getAllCenters,
  updateCenter,
  deleteCenter,
  getUsers,
  createAdmin
};

export default adminService;
