import axios from 'axios';

const api = axios.create({
  baseURL: 'https://sustainability-initiatives-and-centers.onrender.com',
});

// Add a request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const testApi = async () => {
  try {
    const response = await api.get('/test');
    return response.data;
  } catch (error) {
    console.error('API Test Error:', error);
    throw error;
  }
};

export default api;
