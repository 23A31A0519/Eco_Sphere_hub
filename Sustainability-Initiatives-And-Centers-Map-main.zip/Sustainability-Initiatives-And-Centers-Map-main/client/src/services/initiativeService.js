import api from './api';

const getInitiatives = async (filters) => {
  // filters can be an object like { search: 'solar', status: 'ongoing' }
  const params = new URLSearchParams(filters).toString();
  const response = await api.get(`/initiatives?${params}`);
  return response.data;
};

const getInitiativeById = async (id) => {
  const response = await api.get(`/initiatives/${id}`);
  return response.data;
};

const createInitiative = async (data) => {
  const response = await api.post('/initiatives', data);
  return response.data;
};

const updateInitiative = async (id, data) => {
  const response = await api.put(`/initiatives/${id}`, data);
  return response.data;
};

const deleteInitiative = async (id) => {
  const response = await api.delete(`/initiatives/${id}`);
  return response.data;
};

const initiativeService = {
  getInitiatives,
  getInitiativeById,
  createInitiative,
  updateInitiative,
  deleteInitiative,
};

export default initiativeService;
