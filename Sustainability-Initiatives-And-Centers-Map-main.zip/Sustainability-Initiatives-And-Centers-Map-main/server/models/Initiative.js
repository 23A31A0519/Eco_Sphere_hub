const mongoose = require('mongoose');

const initiativeSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide an initiative title'],
  },
  description: {
    type: String,
    required: [true, 'Please provide a description'],
  },
  category: {
    type: String,
    enum: ['Waste', 'Energy', 'Conservation', 'Community'],
    required: [true, 'Please select a category'],
  },
  latitude: {
    type: Number,
    required: [true, 'Please provide latitude'],
  },
  longitude: {
    type: Number,
    required: [true, 'Please provide longitude'],
  },
  city: {
    type: String,
    required: [true, 'Please provide a city'],
  },
  images: {
    type: [String],
  },
  contactInfo: {
    type: String,
  },
  approvalStatus: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  status: {
    type: String,
    enum: ['upcoming', 'ongoing', 'completed'],
    default: 'upcoming',
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Initiative', initiativeSchema);
