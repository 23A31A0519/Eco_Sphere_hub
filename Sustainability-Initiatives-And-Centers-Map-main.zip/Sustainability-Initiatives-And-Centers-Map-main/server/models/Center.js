const mongoose = require('mongoose');

const centerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide center name'],
  },
  description: {
    type: String,
    required: [true, 'Please provide description'],
  },
  category: {
    type: String,
    enum: ['Recycling', 'Waste', 'Energy', 'Water', 'NGO'],
    required: [true, 'Please provide category'],
  },
  latitude: {
    type: Number,
    required: [true, 'Please provide latitude'],
  },
  longitude: {
    type: Number,
    required: [true, 'Please provide longitude'],
  },
  address: {
    type: String,
    required: [true, 'Please provide address'],
  },
  city: {
    type: String,
    required: [true, 'Please provide city'],
  },
  contactInfo: {
    type: String,
  },
  approvalStatus: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Center', centerSchema);
