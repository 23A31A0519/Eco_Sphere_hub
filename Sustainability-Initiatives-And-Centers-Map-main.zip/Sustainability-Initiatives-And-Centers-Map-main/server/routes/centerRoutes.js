const express = require('express');
const {
  createCenter,
  getAllCenters,
  getCenterById,
  updateCenter,
  deleteCenter,
} = require('../controllers/centerController');

const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

const router = express.Router();

router
  .route('/')
  .post(protect, authorize('admin', 'superadmin'), createCenter)
  .get(getAllCenters);

router
  .route('/:id')
  .get(getCenterById)
  .put(protect, authorize('admin', 'superadmin'), updateCenter)
  .delete(protect, authorize('admin', 'superadmin'), deleteCenter);

module.exports = router;
