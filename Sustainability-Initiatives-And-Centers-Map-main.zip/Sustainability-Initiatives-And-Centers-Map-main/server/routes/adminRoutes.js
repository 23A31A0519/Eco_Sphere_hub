const express = require('express');
const {
  getDashboardStats,
  getPendingInitiatives,
  approveInitiative,
  rejectInitiative,
  getAllCenters,
  updateCenter,
  deleteCenter,
  getAllUsers,
  createAdmin
} = require('../controllers/adminController');

const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

const router = express.Router();

// All routes here require at least admin privileges
router.use(protect);

router.get('/stats', authorize('admin', 'superadmin'), getDashboardStats);

// Initiative Management
router.get('/initiatives/pending', authorize('admin', 'superadmin'), getPendingInitiatives);
router.put('/initiatives/:id/approve', authorize('admin', 'superadmin'), approveInitiative);
router.put('/initiatives/:id/reject', authorize('admin', 'superadmin'), rejectInitiative);

// Center Management
router.get('/centers', authorize('admin', 'superadmin'), getAllCenters);
router.put('/centers/:id', authorize('admin', 'superadmin'), updateCenter);
router.delete('/centers/:id', authorize('admin', 'superadmin'), deleteCenter);

// User Management (Superadmin Only)
router.get('/users', authorize('superadmin'), getAllUsers);
router.post('/create-admin', authorize('superadmin'), createAdmin);

module.exports = router;
