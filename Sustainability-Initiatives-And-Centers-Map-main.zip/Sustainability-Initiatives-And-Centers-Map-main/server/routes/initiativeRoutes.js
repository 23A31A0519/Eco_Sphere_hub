const express = require('express');
const {
  createInitiative,
  getAllInitiatives,
  getInitiativeById,
  updateInitiative,
  deleteInitiative,
} = require('../controllers/initiativeController');

const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router
  .route('/')
  .post(protect, createInitiative)
  .get(getAllInitiatives);

router
  .route('/:id')
  .get(getInitiativeById)
  .put(protect, updateInitiative)
  .delete(protect, deleteInitiative);

module.exports = router;
