const Initiative = require('../models/Initiative');
const Center = require('../models/Center');
const User = require('../models/User');
const bcrypt = require('bcryptjs');

// @desc    Get dashboard statistics
// @route   GET /api/admin/stats
// @access  Private (Admin/Superadmin)
exports.getDashboardStats = async (req, res) => {
  try {
    const totalInitiatives = await Initiative.countDocuments();
    const totalCenters = await Center.countDocuments();
    const totalUsers = await User.countDocuments();
    const pendingInitiatives = await Initiative.countDocuments({ approvalStatus: 'pending' });

    res.status(200).json({
      success: true,
      data: {
        totalInitiatives,
        totalCenters,
        totalUsers,
        pendingInitiatives
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error retrieving stats' });
  }
};

// @desc    Get all pending initiatives
// @route   GET /api/admin/initiatives/pending
// @access  Private (Admin/Superadmin)
exports.getPendingInitiatives = async (req, res) => {
  try {
    const initiatives = await Initiative.find({ approvalStatus: 'pending' }).populate('createdBy', 'name email');
    res.status(200).json({ success: true, data: initiatives });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Approve initiative
// @route   PUT /api/admin/initiatives/:id/approve
// @access  Private (Admin/Superadmin)
exports.approveInitiative = async (req, res) => {
  try {
    const initiative = await Initiative.findByIdAndUpdate(
      req.params.id, 
      { approvalStatus: 'approved' }, 
      { new: true, runValidators: true }
    );
    if (!initiative) return res.status(404).json({ success: false, message: 'Initiative not found' });
    res.status(200).json({ success: true, data: initiative });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Reject initiative
// @route   PUT /api/admin/initiatives/:id/reject
// @access  Private (Admin/Superadmin)
exports.rejectInitiative = async (req, res) => {
  try {
    const initiative = await Initiative.findByIdAndUpdate(
      req.params.id, 
      { approvalStatus: 'rejected' }, 
      { new: true, runValidators: true }
    );
    if (!initiative) return res.status(404).json({ success: false, message: 'Initiative not found' });
    res.status(200).json({ success: true, data: initiative });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all centers
// @route   GET /api/admin/centers
// @access  Private (Admin/Superadmin)
exports.getAllCenters = async (req, res) => {
  try {
    const centers = await Center.find().populate('createdBy', 'name');
    res.status(200).json({ success: true, data: centers });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update center (Admin)
// @route   PUT /api/admin/centers/:id
// @access  Private (Admin/Superadmin)
exports.updateCenter = async (req, res) => {
  try {
    const center = await Center.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!center) return res.status(404).json({ success: false, message: 'Center not found' });
    res.status(200).json({ success: true, data: center });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete center (Admin)
// @route   DELETE /api/admin/centers/:id
// @access  Private (Admin/Superadmin)
exports.deleteCenter = async (req, res) => {
  try {
    const center = await Center.findById(req.params.id);
    if (!center) return res.status(404).json({ success: false, message: 'Center not found' });
    await center.deleteOne();
    res.status(200).json({ success: true, message: 'Center deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Superadmin)
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.status(200).json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new admin
// @route   POST /api/admin/create-admin
// @access  Private (Superadmin only)
exports.createAdmin = async (req, res) => {
  try {
    const { name, email, password, region } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ success: false, message: 'User already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      region,
      role: 'admin'
    });

    res.status(201).json({
      success: true,
      data: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        region: user.region
      },
      message: 'Admin created successfully'
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
