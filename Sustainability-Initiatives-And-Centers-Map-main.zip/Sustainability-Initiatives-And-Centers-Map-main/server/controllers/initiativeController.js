const Initiative = require('../models/Initiative');

// @desc    Create new initiative
// @route   POST /api/initiatives
// @access  Private
exports.createInitiative = async (req, res) => {
  try {
    // Add user to req.body
    req.body.createdBy = req.user.id;
    // Force approvalStatus to pending for users creating an initiative
    req.body.approvalStatus = 'pending';

    const initiative = await Initiative.create(req.body);

    res.status(201).json({
      success: true,
      data: initiative,
      message: 'Initiative submitted for approval',
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all approved initiatives (with filters)
// @route   GET /api/initiatives
// @access  Public
exports.getAllInitiatives = async (req, res) => {
  try {
    const { category, city, status, search } = req.query;

    // Base query: ONLY approved initiatives
    let queryArgs = { approvalStatus: 'approved' };

    if (category) queryArgs.category = category;
    if (city) queryArgs.city = city;
    if (status) queryArgs.status = status;
    if (search) {
      queryArgs.title = { $regex: search, $options: 'i' };
    }

    const initiatives = await Initiative.find(queryArgs).sort('-createdAt');

    res.status(200).json({
      success: true,
      count: initiatives.length,
      data: initiatives,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get single initiative
// @route   GET /api/initiatives/:id
// @access  Public
exports.getInitiativeById = async (req, res) => {
  try {
    const initiative = await Initiative.findById(req.params.id).populate('createdBy', 'name');

    if (!initiative) {
      return res.status(404).json({ success: false, message: 'Initiative not found' });
    }

    res.status(200).json({
      success: true,
      data: initiative,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Initiative ID' });
  }
};

// @desc    Update initiative
// @route   PUT /api/initiatives/:id
// @access  Private
exports.updateInitiative = async (req, res) => {
  try {
    let initiative = await Initiative.findById(req.params.id);

    if (!initiative) {
      return res.status(404).json({ success: false, message: 'Initiative not found' });
    }

    // Make sure user is initiative creator or admin
    if (initiative.createdBy.toString() !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'superadmin') {
      return res.status(403).json({ success: false, message: 'Not authorized to update this initiative' });
    }

    initiative = await Initiative.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.status(200).json({
      success: true,
      data: initiative,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete initiative
// @route   DELETE /api/initiatives/:id
// @access  Private
exports.deleteInitiative = async (req, res) => {
  try {
    const initiative = await Initiative.findById(req.params.id);

    if (!initiative) {
      return res.status(404).json({ success: false, message: 'Initiative not found' });
    }

    // Make sure user is initiative creator or admin
    if (initiative.createdBy.toString() !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'superadmin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this initiative' });
    }

    await initiative.deleteOne();

    res.status(200).json({
      success: true,
      data: {},
      message: 'Initiative deleted',
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
