const Center = require('../models/Center');

// @desc    Create new sustainability center
// @route   POST /api/centers
// @access  Private (Admin/Superadmin)
exports.createCenter = async (req, res) => {
  try {
    req.body.createdBy = req.user.id;
    // Admins bypass pending status
    req.body.approvalStatus = 'approved';

    const center = await Center.create(req.body);

    res.status(201).json({
      success: true,
      data: center,
      message: 'Center created successfully',
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all centers (approved)
// @route   GET /api/centers
// @access  Public
exports.getAllCenters = async (req, res) => {
  try {
    const { category, city, search } = req.query;

    let queryArgs = { approvalStatus: 'approved' };

    if (category) queryArgs.category = category;
    if (city) queryArgs.city = city;
    if (search) {
      queryArgs.name = { $regex: search, $options: 'i' };
    }

    const centers = await Center.find(queryArgs).sort('-createdAt');

    res.status(200).json({
      success: true,
      count: centers.length,
      data: centers,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get single center
// @route   GET /api/centers/:id
// @access  Public
exports.getCenterById = async (req, res) => {
  try {
    const center = await Center.findById(req.params.id);

    if (!center) {
      return res.status(404).json({ success: false, message: 'Center not found' });
    }

    res.status(200).json({
      success: true,
      data: center,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Center ID' });
  }
};

// @desc    Update center
// @route   PUT /api/centers/:id
// @access  Private (Admin/Superadmin)
exports.updateCenter = async (req, res) => {
  try {
    const center = await Center.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!center) {
      return res.status(404).json({ success: false, message: 'Center not found' });
    }

    res.status(200).json({
      success: true,
      data: center,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete center
// @route   DELETE /api/centers/:id
// @access  Private (Admin/Superadmin)
exports.deleteCenter = async (req, res) => {
  try {
    const center = await Center.findById(req.params.id);

    if (!center) {
      return res.status(404).json({ success: false, message: 'Center not found' });
    }

    await center.deleteOne();

    res.status(200).json({
      success: true,
      data: {},
      message: 'Center deleted successfully',
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
