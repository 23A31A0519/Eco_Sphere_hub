const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Body parser
app.use(express.json());

// Enable CORS
app.use(cors({
    origin: "https://your-frontend-url.vercel.app",
    credentials: true
}));

// Routes
const authRoutes = require('./routes/authRoutes');
const initiativeRoutes = require('./routes/initiativeRoutes');
const centerRoutes = require('./routes/centerRoutes');
const adminRoutes = require('./routes/adminRoutes');

app.use('/api/auth', authRoutes);
app.use('/api/initiatives', initiativeRoutes);
app.use('/api/centers', centerRoutes);
app.use('/api/admin', adminRoutes);

// Test Route
app.get('/api/test', (req, res) => {
    res.json({ message: "EcoSphere API is working" });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
